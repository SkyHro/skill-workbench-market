export type Slot = "skill.detail" | "diagnosis.summary";
export interface Contribution {
  id: string;
  slot: Slot;
  type: "panel" | "markdown";
  title: string;
}
export interface Context {
  readonly slot: Slot;
  readonly contributionId: string;
  readonly skill: {
    name: string;
    description: string;
    dependencies: string[];
    issues: string[];
    references: { kind: string }[];
  };
}
export interface Engines { workbench: string }
export const legacyWorkbenchRange: string;
export function parseEngines(value: unknown): Engines | undefined;
export function supportsWorkbench(version: string, engines?: Engines): boolean;
export interface Extension {
  engines?: Engines;
  apiVersion: 2;
  kind: "extension";
  trial: false;
  id: string;
  version: string;
  name: string;
  publisher: string;
  description: string;
  contributions: Contribution[];
  source: string;
}
export type Activate = (context: Context) => string;
export function validatePlugin(value: unknown): Extension;

export function validateExtensionHeader(value: unknown): Omit<Extension, "source">;

export interface ContributionMetadata { id: string; slot: string; type: string; title: string }
export function readExtensionMetadata(value: unknown): Omit<Extension, "source" | "contributions"> & { contributions: ContributionMetadata[] };
