#!/usr/bin/env node
import { readFile } from "node:fs/promises";

async function publish() {
  const [filename, address = process.env.SKILL_WORKBENCH_MARKET_URL] = process.argv.slice(2);
  const token = process.env.WORKBENCH_PUBLISH_TOKEN;
  if (!filename || !address || !token) throw new Error("用法：workbench-publish 插件包.json 市场地址，需要 WORKBENCH_PUBLISH_TOKEN");
  const url = new URL("publish", address.replace(/\/?$/, "/"));
  if (url.username || url.password || !(url.protocol === "https:" ||
      (url.protocol === "http:" && ["127.0.0.1", "[::1]", "localhost"].includes(url.hostname))))
    throw new Error("发布地址需要 HTTPS 或本机 HTTP");
  const bytes = await readFile(filename);
  if (bytes.length > 131072) throw new Error("插件包超过 128 KiB");
  const response = await fetch(url, {method:"POST", headers: {
    authorization: "Bearer " + token, "content-type":"application/json"
  }, body:bytes, redirect:"error", signal:AbortSignal.timeout(15000)});
  if (!response.ok) throw new Error("发布失败 HTTP " + response.status + " " + (await response.text()).slice(0, 300));
  const result = await response.json();
  console.log("已上架", result.id, result.version);
}
publish().catch(e => { console.error(e.message); process.exitCode = 1; });
