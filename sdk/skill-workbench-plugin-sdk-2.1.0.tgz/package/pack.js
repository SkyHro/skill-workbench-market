#!/usr/bin/env node
import { readFile, writeFile } from "node:fs/promises";
import { validatePlugin } from "./index.js";
const [manifest, entry, output] = process.argv.slice(2);
if (!output) throw new Error("用法：workbench-pack manifest.json activate.js output.json");
const metadata = JSON.parse(await readFile(manifest, "utf8"));
const source = await readFile(entry, "utf8");
const plugin = validatePlugin({ ...metadata, source });
await writeFile(output, JSON.stringify(plugin));
console.log(output);
