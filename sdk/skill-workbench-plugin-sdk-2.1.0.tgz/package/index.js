import semver from "semver";

// Packages released before engines was introduced targeted the 0.1 desktop line.
export const legacyWorkbenchRange = ">=0.1.0 <0.2.0";
export function parseEngines(engines) {
  if (engines === undefined) return undefined;
  const range = engines?.workbench;
  if (typeof range !== "string" || !range.trim() || range.length > 160 || !semver.validRange(range))
    throw new Error("engines.workbench 需要有效的 SemVer 版本范围");
  return {workbench:range.trim()};
}
export function supportsWorkbench(version, engines) {
  return semver.satisfies(version, engines?.workbench ?? legacyWorkbenchRange);
}
// Imported by both the author's CLI and the desktop package loader.
export function readExtensionMetadata(value) {
  function check(ok, message) {
    if (!ok) throw new Error("插件清单无效：" + message);
  }
  function text(obj, key, max) {
    check(typeof obj[key] === "string" && obj[key].trim() && obj[key].length <= max, key);
    return obj[key];
  }
  check(value && value.apiVersion === 2 && value.kind === "extension" && value.trial === false, "API 2 / extension / trial");
  const engines = parseEngines(value.engines);
  const idPattern = /^[a-z][a-z0-9.-]{0,79}$/;
  const result = { apiVersion: 2, kind: "extension", trial: false, ...(engines && {engines}) };
  for (const [key, size] of Object.entries({ id: 80, version: 32, name: 80, publisher: 120, description: 2000 })) {
    result[key] = text(value, key, size);
  }
  check(idPattern.test(result.id) && /^\d{1,6}\.\d{1,6}\.\d{1,6}$/.test(result.version), "id / version");
  check(Array.isArray(value.contributions) && value.contributions.length > 0 && value.contributions.length <= 16, "contributions");
  const ids = new Set();
  result.contributions = value.contributions.map(item => {
    check(item && typeof item === "object", "contribution");
    const id = text(item, "id", 80);
    check(idPattern.test(id) && !ids.has(id), "贡献 ID 无效或重复");
    ids.add(id);
    return { id, slot: text(item, "slot", 80), type: text(item, "type", 80), title: text(item, "title", 100) };
  });
  return result;
}
export function validateExtensionHeader(value) {
  const header = readExtensionMetadata(value);
  for (const item of header.contributions) {
    if (!["skill.detail", "diagnosis.summary"].includes(item.slot)) throw new Error("未知扩展点 " + item.slot);
    if (!["panel", "markdown"].includes(item.type)) throw new Error("未知能力 " + item.type);
  }
  return header;
}
export function validatePlugin(value) {
  const result = validateExtensionHeader(value);
  if (typeof value.source !== "string" || !value.source.trim() || value.source.length > 96000)
    throw new Error("插件清单无效：source");
  result.source = value.source;
  if (new TextEncoder().encode(JSON.stringify(result)).length > 131072) throw new Error("超过 128 KiB");
  return result;
}
